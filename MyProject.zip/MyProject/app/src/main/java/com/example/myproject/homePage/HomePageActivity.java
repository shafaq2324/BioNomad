package com.example.myproject.homePage;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myproject.bookings.BookingActivity;
import com.example.myproject.budgetTracker.BudgetActivity;
import com.example.myproject.R;
import com.example.myproject.currencyConvert.CurrencyConverter;
import com.example.myproject.myGallery.ImageActivity;
import com.example.myproject.signIn.LoginActivity;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import java.util.ArrayList;
import java.util.List;

public class HomePageActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private ImageView menuBar;
    private FirebaseAuth firebaseAuth;
    private RecyclerView recentRecycler, topPlacesRecycler;
    private RecentsAdapter recentsAdapter;
    TopPlacesAdapter topPlacesAdapter;
    private TextView seeAllTxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        firebaseAuth = FirebaseAuth.getInstance();

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        menuBar = findViewById(R.id.menu_bar);
        seeAllTxt = findViewById(R.id.seeAllTxt);


        String[] recent_names = getResources().getStringArray(R.array.recents_names);
        String[] recent_state = getResources().getStringArray(R.array.recents_states);
        String[] recent_prices = getResources().getStringArray(R.array.recents_prices);
        String[] recent_pictures = getResources().getStringArray(R.array.recents_images);
        String[] recent_Desc = getResources().getStringArray(R.array.recents_description);
        List<RecentsData> recentsDataList = new ArrayList<>();
        recentsDataList.add(new RecentsData(recent_names[0], recent_state[0], recent_prices[0], recent_pictures[0], recent_Desc[0])); //Shimla
        recentsDataList.add(new RecentsData(recent_names[10], recent_state[10], recent_prices[10], recent_pictures[10], recent_Desc[10])); // Leh Ladakh
        recentsDataList.add(new RecentsData(recent_names[18], recent_state[18], recent_prices[18], recent_pictures[18], recent_Desc[18])); //Pelling
        recentsDataList.add(new RecentsData(recent_names[21], recent_state[21], recent_prices[21], recent_pictures[21], recent_Desc[21])); // Kaziranga
        recentsDataList.add(new RecentsData(recent_names[23], recent_state[23], recent_prices[23], recent_pictures[23], recent_Desc[23])); //Sundarban
        recentsDataList.add(new RecentsData(recent_names[27], recent_state[27], recent_prices[27], recent_pictures[27], recent_Desc[27])); // Taj Mahal

        setRecentRecycler(recentsDataList);

        List<TopPLacesData> topPlacesDataList = new ArrayList<>();
        topPlacesDataList.add(new TopPLacesData(recent_names[3], recent_state[3], recent_prices[3],recent_pictures[3], recent_Desc[3]));
        topPlacesDataList.add(new TopPLacesData(recent_names[4], recent_state[4], recent_prices[4],recent_pictures[4], recent_Desc[4]));
        topPlacesDataList.add(new TopPLacesData(recent_names[8], recent_state[8], recent_prices[8],recent_pictures[8], recent_Desc[8]));
        topPlacesDataList.add(new TopPLacesData(recent_names[25], recent_state[25], recent_prices[25],recent_pictures[25], recent_Desc[25]));

        setTopPlacesRecycler(topPlacesDataList);


        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this,
                drawerLayout,
                R.string.navigation_drawer_open,
                R.string.navigation_drawer_close
        );
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        menuBar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
        navigationView.setBackgroundColor(ContextCompat.getColor(this, android.R.color.white));


        seeAllTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePageActivity.this, SeeAllActivity.class));
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.logout) {
                    firebaseAuth.signOut();
                    startActivity(new Intent(HomePageActivity.this, LoginActivity.class));
                    finish();
                    return true;
                } else if (item.getItemId() == R.id.currencyConvert) {
                    startActivity(new Intent(HomePageActivity.this, CurrencyConverter.class));
                    return true;
                } else if (item.getItemId() == R.id.photos) {
                    startActivity(new Intent(HomePageActivity.this, ImageActivity.class));
                    return true;
                }
                else if(item.getItemId() == R.id.budgetTracker){
                    startActivity(new Intent(HomePageActivity.this, BudgetActivity.class));
                    return true;
                }
                else if(item.getItemId() == R.id.booking){
                    startActivity(new Intent(HomePageActivity.this, BookingActivity.class));
                    return true;
                }

                return false;
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

    private void setRecentRecycler(List<RecentsData> recentsDataList) {
        recentRecycler = findViewById(R.id.recent_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.HORIZONTAL, false);
        recentRecycler.setLayoutManager(layoutManager);
        recentsAdapter = new RecentsAdapter(this, recentsDataList);
        recentRecycler.setAdapter(recentsAdapter);
    }



    private void setTopPlacesRecycler(List<TopPLacesData> topPlacesDataList) {
        topPlacesRecycler = findViewById(R.id.top_places_recycler);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, RecyclerView.VERTICAL, false);
        topPlacesRecycler.setLayoutManager(layoutManager);
        topPlacesAdapter = new TopPlacesAdapter(this, topPlacesDataList);
        topPlacesRecycler.setAdapter(topPlacesAdapter);
    }
}


