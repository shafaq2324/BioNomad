package com.example.myproject.homePage;

public class RecentsData {
    String placeName;
    String countryName;
    String price;
    String imageUrl;
    String description;

    public RecentsData(String placeName, String countryName, String price, String imageUrl, String description){
        this.placeName = placeName;
        this.countryName = countryName;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
    }

    public String getPlaceName(){
        return placeName;
    }
    public void setPlaceName(){
        this.placeName = placeName;
    }

    public String getCountryName(){
        return countryName;
    }
    public void setCountryName(){
        this.countryName = countryName;
    }

    public String getPrice(){
        return price;
    }
    public void setPrice(){
        this.price = price;
    }

    public String getImageUrl(){
        return imageUrl;
    }

    public void setImageUrl(){
        this.imageUrl = imageUrl;
    }

    public String getDescription(){ return description;}
    public void setDescription(){ this.description = description;}
}
