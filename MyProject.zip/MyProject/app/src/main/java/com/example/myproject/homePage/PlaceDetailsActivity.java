package com.example.myproject.homePage;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.myproject.R;

public class PlaceDetailsActivity extends AppCompatActivity {

    private ImageView back;
    private TextView placeName, placeState, placePrice;
    private ImageView placeImage;
    private TextView placeDescription;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_details);

        back = findViewById(R.id.back_btn);

        placeName = findViewById(R.id.mplaceName);
        placeState = findViewById(R.id.mplaceState);
        placePrice = findViewById(R.id.mplacePrice);
        placeImage = findViewById(R.id.mplaceImage);
        placeDescription = findViewById(R.id.placeDesc);

        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String state = intent.getStringExtra("state");
        String price = intent.getStringExtra("price");
        String picture = intent.getStringExtra("image_url");
        String description = intent.getStringExtra("description");

        placeName.setText(name);
        placeState.setText(state);
        placePrice.setText(price);
        placeDescription.setText(description);

        if (picture != null) {
            Glide.with(this)
                    .load(picture)
                    .into(placeImage);
        }

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(PlaceDetailsActivity.this, HomePageActivity.class));

            }
        });

    }
}