package com.example.myproject.homePage;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myproject.R;

import java.util.List;

public class RecentsAdapter extends RecyclerView.Adapter<RecentsAdapter.RecentsViewHolder> {

    private Context context;
    private List<RecentsData> recentsDataList;

    // Constructor
    public RecentsAdapter(Context context, List<RecentsData> recentsDataList) {
        this.context = context;
        this.recentsDataList = recentsDataList;
    }

    @NonNull
    @Override
    public RecentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for the individual items in the RecyclerView
        View view = LayoutInflater.from(context).inflate(R.layout.recent_row_item, parent, false);
        return new RecentsViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecentsViewHolder holder, int position) {
        // Bind data to the views in each ViewHolder
        RecentsData recentsData = recentsDataList.get(position);
        holder.countryName.setText(recentsData.getCountryName());
        holder.placeName.setText(recentsData.getPlaceName());
        holder.price.setText(recentsData.getPrice());

        // Load image using Glide
        Glide.with(context)
                .load(recentsData.getImageUrl())
                .into(holder.placeImage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, PlaceDetailsActivity.class);
                i.putExtra("name", recentsData.getPlaceName());
                i.putExtra("state", recentsData.getCountryName()); // Assuming country name as state
                i.putExtra("price", recentsData.getPrice());
                i.putExtra("image_url", recentsData.getImageUrl());
                i.putExtra("description", recentsData.getDescription());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        // Return the size of the data list
        return recentsDataList.size();
    }

    // ViewHolder class to represent each item
    public static class RecentsViewHolder extends RecyclerView.ViewHolder {

        ImageView placeImage;
        TextView placeName, countryName, price;

        public RecentsViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize the views from the layout
            placeImage = itemView.findViewById(R.id.tplace_image);
            placeName = itemView.findViewById(R.id.tplace_name);
            countryName = itemView.findViewById(R.id.tcountry_name);
            price = itemView.findViewById(R.id.tplace_price);
        }
    }
}

