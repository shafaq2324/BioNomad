package com.example.myproject.homePage;

public class SeeAllData {
    private String name;
    private String state;
    private String price;
    private String imageUrl;

    private String description;


    public SeeAllData(String name, String state, String price, String imageUrl, String description) {
        this.name = name;
        this.state = state;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getState() {
        return state;
    }

    public String getPrice() {
        return price;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getDescription(){return description;}


}
