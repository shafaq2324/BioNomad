package com.example.myproject.budgetTracker

import androidx.room.Database
import androidx.room.RoomDatabase


@Database(entities = arrayOf(Transaction::class), version = 1)
abstract class BudgetDatabase: RoomDatabase() {
    abstract fun transactionDao(): TransDao
}