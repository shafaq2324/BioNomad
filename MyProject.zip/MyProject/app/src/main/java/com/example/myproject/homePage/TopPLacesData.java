package com.example.myproject.homePage;

public class TopPLacesData {
    private String placeName;
    private String countryName;
    private String price;
    private String imageUrl;
    private String description;

    public TopPLacesData(String placeName, String countryName, String price, String imageUrl, String description) {
        this.placeName = placeName;
        this.countryName = countryName;
        this.price = price;
        this.imageUrl = imageUrl;
        this.description = description;
    }

    public String getPlaceName() {
        return placeName;
    }

    public String getCountryName() {
        return countryName;
    }

    public String getPrice() {
        return price;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getDescription(){return description;}
}
