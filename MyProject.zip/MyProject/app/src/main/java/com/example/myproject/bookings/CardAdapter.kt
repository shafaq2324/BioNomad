package com.example.myproject.bookings

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import com.example.myproject.R

class CardAdapter(
    private val context: Context,
    private val iconIds: IntArray,
    private val urls: Array<String>
) : RecyclerView.Adapter<CardAdapter.CardViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CardViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.card_item, parent, false)
        return CardViewHolder(view)
    }

    override fun onBindViewHolder(holder: CardViewHolder, position: Int) {
        holder.iconImageView.setImageResource(iconIds[position])
        holder.cardView.setOnClickListener {

            val message = when (position) {
                0 -> "Enjoy your journey!" // Train card clicked
                1 -> "Enjoy your flight!" // Train card clicked
                2 -> "Enjoy your ride!" // Bus card clicked
                else -> "No message available" // Fallback message
            }

            // Show the toast message
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(urls[position]))
            context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int = iconIds.size

    inner class CardViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val iconImageView: ImageView = itemView.findViewById(R.id.cardIcon)
        val cardView: CardView = itemView as CardView
    }
}