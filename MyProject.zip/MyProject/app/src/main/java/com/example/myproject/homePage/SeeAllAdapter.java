package com.example.myproject.homePage;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myproject.R;

import java.util.List;

public class SeeAllAdapter extends RecyclerView.Adapter<SeeAllAdapter.SeeAllViewHolder> {

    private Context context;
    private List<SeeAllData> seeAllDataList;


    public SeeAllAdapter(Context context, List<SeeAllData> seeAllDataList){
        this.context = context;
        this.seeAllDataList = seeAllDataList;
    }


    @NonNull
    @Override
    public SeeAllViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.see_all_item_layout, parent, false);
        return new SeeAllViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SeeAllAdapter.SeeAllViewHolder holder, int position) {
        SeeAllData seeAll = seeAllDataList.get(position);

        holder.name.setText(seeAll.getName());
        holder.state.setText(seeAll.getState());
        holder.price.setText(seeAll.getPrice());

        Glide.with(context)
                .load(seeAll.getImageUrl())
                .into(holder.image);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, PlaceDetailsActivity.class);
                i.putExtra("name", seeAll.getName());
                i.putExtra("state", seeAll.getState()); // Assuming country name as state
                i.putExtra("price", seeAll.getPrice());
                i.putExtra("image_url", seeAll.getImageUrl());
                i.putExtra("description", seeAll.getDescription());
                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        return seeAllDataList.size();
    }

    public static class SeeAllViewHolder extends RecyclerView.ViewHolder {
        ImageView image;
        TextView name, state, price, descriptionTextView;

        public SeeAllViewHolder(@NonNull View itemView) {
            super(itemView);
            image = itemView.findViewById(R.id.seeAllImage);
            name = itemView.findViewById(R.id.seeAllName);
            state = itemView.findViewById(R.id.seeAllState);
            price = itemView.findViewById(R.id.seeAllPrice);
        }
    }
}
