package com.example.myproject.myGallery

import android.net.Uri

data class ImageItem(val uri: Uri)
