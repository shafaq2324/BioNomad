package com.example.myproject.bookings

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.myproject.R

class BookingActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking)

        val recyclerView: RecyclerView = findViewById(R.id.bookingRecyclerView)

        val iconIds = intArrayOf(
            R.drawable.train,   // Replace with your actual icon resource IDs
            R.drawable.flight,
            R.drawable. bus
        )
        val urls = arrayOf(
            "https://www.railyatri.in/",
            "https://www.skyscanner.net/",
            "https://www.abhibus.com/"
        )

        val adapter = CardAdapter(this, iconIds, urls)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = adapter
    }

}