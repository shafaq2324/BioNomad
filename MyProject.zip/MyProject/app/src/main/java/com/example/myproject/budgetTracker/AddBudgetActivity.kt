package com.example.myproject.budgetTracker

import android.os.Bundle
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import androidx.room.Room
import com.example.myproject.R
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class AddBudgetActivity : AppCompatActivity() {

    private lateinit var closeBtn: ImageButton
    private lateinit var addTransaction: Button
    private lateinit var labelInput: TextInputEditText
    private lateinit var amountInput: TextInputEditText
    private lateinit var descInput: TextInputEditText
    private lateinit var labelLayout: TextInputLayout
    private lateinit var amountLayout: TextInputLayout
    private lateinit var expenseCheckbox: CheckBox

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_budget)

        addTransaction = findViewById(R.id.add_transaction_btn)
        labelInput = findViewById(R.id.labelInput)
        amountInput = findViewById(R.id.amountInput)
        descInput = findViewById(R.id.descInput)
        labelLayout = findViewById(R.id.labelLayout)
        amountLayout = findViewById(R.id.amountLayout)
        closeBtn = findViewById(R.id.closeBtn)
        expenseCheckbox = findViewById(R.id.checkbox_expense)

        labelInput.addTextChangedListener {
            if (it!!.count() > 0) {
                labelLayout.error = null
            }
        }

        amountInput.addTextChangedListener {
            if (it!!.count() > 0) {
                amountLayout.error = null
            }
        }

        addTransaction.setOnClickListener {
            val label = labelInput.text.toString()
            val amountString = amountInput.text.toString()
            val description = descInput.text.toString()

            if (label.isEmpty()) {
                labelLayout.error = "Please enter valid label"
            } else if (amountString.isEmpty()) {
                amountLayout.error = "Please enter valid amount"
            } else {
                val amount = amountString.toDoubleOrNull() ?: 0.0
                val finalAmount = if (expenseCheckbox.isChecked) -amount else amount
                val transaction = Transaction(0, label, finalAmount, description)
                insert(transaction)
            }
        }

        closeBtn.setOnClickListener {
            finish()
        }

    }

    private fun insert(transaction: Transaction) {
        val db = Room.databaseBuilder(this,
            BudgetDatabase::class.java,
            "transactions").build()

        GlobalScope.launch {
            db.transactionDao().insertAll(transaction)
            finish()
        }
    }

}