package com.example.myproject.currencyConvert

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.myproject.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.URL

class CurrencyConverter : AppCompatActivity() {

    private var baseCurrency = "INR"
    private var convertedToCurrency = "USD"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_currency_converter)

        setupSpinners()
        setupEditTextListener()
    }

    private fun setupEditTextListener() {
        val etFirstConversion = findViewById<EditText>(R.id.et_firstConversion)
        etFirstConversion.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {
                Log.d("CurrencyConverter", "Before Text Changed")
            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                Log.d("CurrencyConverter", "On Text Changed")
            }

            override fun afterTextChanged(s: Editable?) {
                if (!s.isNullOrEmpty()) {
                    getAPIResult()
                } else {
                    Toast.makeText(
                        applicationContext,
                        "Please type a value",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        })
    }

    private fun getAPIResult() {
        val etFirstConversion = findViewById<EditText>(R.id.et_firstConversion)
        if (etFirstConversion.text.isNotEmpty() && etFirstConversion.text.isNotBlank()) {
            val apiUrl = "https://v6.exchangerate-api.com/v6/8dacba4b99ad7df62587200f/latest/$baseCurrency"

            if (baseCurrency == convertedToCurrency) {
                Toast.makeText(
                    applicationContext,
                    "Please enter different currencies",
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

            GlobalScope.launch(Dispatchers.IO) {
                try {
                    val apiResult = URL(apiUrl).readText()
                    val jsonObject = JSONObject(apiResult)
                    val conversionRate = jsonObject.getJSONObject("conversion_rates").getString(convertedToCurrency).toFloat()

                    Log.d("CurrencyConverter", "Conversion Rate: $conversionRate")
                    Log.d("CurrencyConverter", apiResult)

                    withContext(Dispatchers.Main) {
                        val convertedAmount = (etFirstConversion.text.toString().toFloat() * conversionRate).toString()
                        val etSecondConversion = findViewById<EditText>(R.id.et_secondConversion)
                        etSecondConversion.setText(convertedAmount)
                    }

                } catch (e: Exception) {
                    Log.e("CurrencyConverter", "Error: ${e.message}")
                }
            }
        }
    }

    private fun setupSpinners() {
        val spinnerBaseCurrency = findViewById<Spinner>(R.id.spinner_firstConversion)
        val spinnerConvertedCurrency = findViewById<Spinner>(R.id.spinner_secondConversion)

        ArrayAdapter.createFromResource(
            this, R.array.FromCurrencies, android.R.layout.simple_spinner_item
        ).also { adapter ->
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerBaseCurrency.adapter = adapter
            spinnerConvertedCurrency.adapter = adapter
        }

        spinnerBaseCurrency.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                baseCurrency = parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerConvertedCurrency.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                convertedToCurrency = parent?.getItemAtPosition(position).toString()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

}