package com.example.myproject.budgetTracker

import android.content.Context
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.ImageButton
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import androidx.room.Room
import com.example.myproject.R
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class BudgetDetailsActivity : AppCompatActivity() {

    private lateinit var transaction: Transaction
    private lateinit var exitBtn: ImageButton
    private lateinit var updateTransaction: Button
    private lateinit var labelInput2: TextInputEditText
    private lateinit var amountInput2: TextInputEditText
    private lateinit var descInput2: TextInputEditText
    private lateinit var labelLayout2: TextInputLayout
    private lateinit var amountLayout2: TextInputLayout
    private lateinit var rootView: ConstraintLayout
    private lateinit var checkboxExpense: CheckBox
    private var isExpense: Boolean = false
    private var originalAmount: Double = 0.0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_budget_details)

        @Suppress("DEPRECATION")
        transaction = intent.getSerializableExtra("transactions") as Transaction

        updateTransaction = findViewById(R.id.update_btn)
        labelInput2 = findViewById(R.id.labelInput2)
        amountInput2 = findViewById(R.id.amountInput2)
        descInput2 = findViewById(R.id.descInput2)
        labelLayout2 = findViewById(R.id.labelLayout2)
        amountLayout2 = findViewById(R.id.amountLayout2)
        exitBtn = findViewById(R.id.exit)
        rootView = findViewById(R.id.rootView)
        checkboxExpense = findViewById(R.id.checkbox_expense2)

        // Initialize UI elements with the current transaction details
        labelInput2.setText(transaction.label)
        amountInput2.setText(transaction.amount.toString())
        descInput2.setText(transaction.description)
        checkboxExpense.isChecked = transaction.amount < 0 // Assume negative amount means expense

        // Update original amount and expense status
        originalAmount = transaction.amount
        isExpense = originalAmount < 0

        rootView.setOnClickListener {
            this.window.decorView.clearFocus()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(it.windowToken, 0)
        }

        labelInput2.addTextChangedListener {
            updateTransaction.visibility = View.VISIBLE
            if (it!!.count() > 0) {
                labelLayout2.error = null
            }
        }

        amountInput2.addTextChangedListener {
            updateTransaction.visibility = View.VISIBLE
            if (it!!.count() > 0) {
                amountLayout2.error = null
            }
        }

        descInput2.addTextChangedListener {
            updateTransaction.visibility = View.VISIBLE
        }

        checkboxExpense.setOnCheckedChangeListener { _, isChecked ->
            isExpense = isChecked
            // Update amount based on checkbox state
            val currentAmount = amountInput2.text.toString().toDoubleOrNull() ?: originalAmount
            val updatedAmount = if (isExpense) -currentAmount else Math.abs(currentAmount)
            amountInput2.setText(updatedAmount.toString())
        }

        updateTransaction.setOnClickListener {
            val label = labelInput2.text.toString()
            val amount = amountInput2.text.toString().toDoubleOrNull()
            val description = descInput2.text.toString()

            if (label.isEmpty()) {
                labelLayout2.error = "Please enter valid label"
            } else if (amount == null) {
                amountLayout2.error = "Please enter valid amount"
            } else {
                val transaction = Transaction(transaction.id, label, amount, description)
                update(transaction)
            }
        }

        exitBtn.setOnClickListener {
            finish()
        }

    }


    private fun update(transaction: Transaction) {
        val db = Room.databaseBuilder(this,
            BudgetDatabase::class.java,
            "transactions").
        fallbackToDestructiveMigration().build()

        GlobalScope.launch {
            db.transactionDao().update(transaction)
            finish()
        }
    }

}