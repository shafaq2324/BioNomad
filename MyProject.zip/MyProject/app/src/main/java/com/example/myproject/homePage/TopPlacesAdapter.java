package com.example.myproject.homePage;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.myproject.R;

import java.util.List;

public class TopPlacesAdapter extends RecyclerView.Adapter<TopPlacesAdapter.TopPlacesViewHolder> {

    private Context context;
    private List<TopPLacesData> topPlacesDataList;

    // Declare these arrays as class-level variables
    private String[] topPlacesNames;
    private String[] topPlacesCountries;
    private String[] topPlacesPrices;

    // Constructor
    public TopPlacesAdapter(Context context, List<TopPLacesData> topPlacesDataList) {
        this.context = context;
        this.topPlacesDataList = topPlacesDataList;

    }

    @NonNull
    @Override
    public TopPlacesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the layout for the individual items in the RecyclerView
        View view = LayoutInflater.from(context).inflate(R.layout.top_places_row_item, parent, false);
        return new TopPlacesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TopPlacesViewHolder holder, int position) {
        TopPLacesData topPlace = topPlacesDataList.get(position);

        // Set text from the TopPLacesData object
        holder.placeName.setText(topPlace.getPlaceName());
        holder.countryName.setText(topPlace.getCountryName());
        holder.price.setText(topPlace.getPrice());

        // Load image using Glide
        Glide.with(context)
                .load(topPlace.getImageUrl())
                .into(holder.placeImage);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(context, PlaceDetailsActivity.class);
                i.putExtra("name", topPlace.getPlaceName());
                i.putExtra("state", topPlace.getCountryName()); // Assuming country name as state
                i.putExtra("price", topPlace.getPrice());
                i.putExtra("image_url", topPlace.getImageUrl());
                i.putExtra("description", topPlace.getDescription());
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        // Return the size of the data list
        return topPlacesDataList.size();
    }

    // ViewHolder class to represent each item
    public static class TopPlacesViewHolder extends RecyclerView.ViewHolder {

        ImageView placeImage;
        TextView placeName, countryName, price;

        public TopPlacesViewHolder(@NonNull View itemView) {
            super(itemView);

            // Initialize the views from the layout
            placeImage = itemView.findViewById(R.id.tplace_image);
            placeName = itemView.findViewById(R.id.tplace_name);
            countryName = itemView.findViewById(R.id.tcountry_name);
            price = itemView.findViewById(R.id.tplace_price);
        }
    }
}
