package com.example.myproject.myGallery

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.example.myproject.R

class ImageActivity : AppCompatActivity() {

    private val imageList = mutableListOf<ImageItem>()
    private lateinit var imageAdapter: ImageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_image)

        val selectImagesButton: Button = findViewById(R.id.selectImagesButton)
        val recyclerView: RecyclerView = findViewById(R.id.imagesRecyclerView)

        imageAdapter = ImageAdapter(imageList, { position ->
            imageAdapter.removeItem(position)
        }, { uri ->
            viewImage(uri)
        })

        val staggeredGridLayoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        recyclerView.layoutManager = staggeredGridLayoutManager
        recyclerView.adapter = imageAdapter

        selectImagesButton.setOnClickListener {
            selectImages()
        }
    }

    private fun selectImages() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        @Suppress("DEPRECATION")
        startActivityForResult(intent, PICK_IMAGES_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGES_REQUEST && resultCode == Activity.RESULT_OK) {
            data?.let {
                val clipData = it.clipData
                if (clipData != null) {
                    for (i in 0 until clipData.itemCount) {
                        val imageUri = clipData.getItemAt(i).uri
                        imageList.add(ImageItem(imageUri))
                    }
                } else {
                    val imageUri = it.data
                    imageUri?.let { uri ->
                        imageList.add(ImageItem(uri))
                    }
                }
                imageAdapter.notifyDataSetChanged()
            }
        }
    }

    private fun viewImage(uri: Uri) {
        val intent = Intent(this, ImageViewActivity::class.java)
        intent.putExtra("image_uri", uri.toString())
        startActivity(intent)
    }

    companion object {
        private const val PICK_IMAGES_REQUEST = 1
    }
}