package com.example.myproject.homePage;


import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myproject.R;

import java.util.ArrayList;
import java.util.List;

public class SeeAllActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private SeeAllAdapter seeAllAdapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_see_all);

        recyclerView = findViewById(R.id.seeAllRecycler);

        String[] names = getResources().getStringArray(R.array.recents_names);
        String[] states = getResources().getStringArray(R.array.recents_states);
        String[] prices = getResources().getStringArray(R.array.recents_prices);
        String[] images = getResources().getStringArray(R.array.recents_images);
        String[] description = getResources().getStringArray(R.array.recents_description);

        List<SeeAllData> dataList = new ArrayList<>();
        for(int i = 0; i < names.length; i++){
            dataList.add(new SeeAllData(names[i], states[i], prices[i], images[i], description[i]));
            Log.d("SeeAllActivity", "Added item: " + names[i] + ", " + states[i] + ", " + prices[i] + ", " + images[i]);
        }

        seeAllAdapter = new SeeAllAdapter(this, dataList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(seeAllAdapter);

        Log.d("SeeAllActivity", "Adapter set with item count: " + dataList.size());
    }

}
